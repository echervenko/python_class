# Instructions

#### This is our test project.

#### Please istall this package 

```
pip install functions-by-echervenko
```

#### You can also install older package
```
pip install functions-by-echervenko==VERSION_NUMBER
```